
      let global = globalThis;

      class MessageChannel {
        constructor() {
          this.port1 = new MessagePort();
          this.port2 = new MessagePort();
        }
      }
      class MessagePort {
        constructor() {
          this.onmessage = null;
        }
        postMessage(data) {
          if (this.onmessage) {
            setTimeout(() => this.onmessage({ data }), 0);
          }
        }
      }
      global.MessageChannel = MessageChannel;

      async function handleRequest(context){
        let routeParams = {};
        let pagesFunctionResponse = null;
        const request = context.request;
        const waitUntil = context.waitUntil;
        const urlInfo = new URL(request.url);

        if (urlInfo.pathname !== '/' && urlInfo.pathname.endsWith('/')) {
          urlInfo.pathname = urlInfo.pathname.slice(0, -1);
        }

        let matchedFunc = false;
        
            if(!matchedFunc && '/api/1/configs' === urlInfo.pathname && request.method === 'GET') {
              matchedFunc = true;
                "use strict";
(() => {
  // edge-functions/utils.js
  async function sha512(str) {
    const encodeContent = new TextEncoder().encode(str);
    const sha256Content = await crypto.subtle.digest(
      { name: "SHA-512" },
      encodeContent
    );
    const result = new Uint8Array(sha256Content);
    const hexString = Array.from(result).map((b) => b.toString(16).padStart(2, "0")).join("");
    return hexString;
  }
  async function checkToken(token) {
    if (!token || token.length !== 64) {
      return false;
    }
    const expectedToken = await sha512(token);
    let user_info = await kv_users.get(expectedToken, "json");
    return user_info;
  }
  async function importKey(keyHex) {
    const rawKey = new Uint8Array(
      keyHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16))
    );
    return await crypto.subtle.importKey(
      "raw",
      rawKey,
      {
        name: "AES-GCM",
        length: 256
      },
      true,
      ["encrypt", "decrypt"]
    );
  }
  async function encrypt(key, plaintext) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encoder = new TextEncoder();
    const data = encoder.encode(plaintext);
    const encryptedData = await crypto.subtle.encrypt(
      {
        name: "AES-GCM",
        iv
      },
      key,
      data
    );
    const encryptedDataHex = Array.from(new Uint8Array(encryptedData)).map((b) => b.toString(16).padStart(2, "0")).join("");
    const ivHex = Array.from(new Uint8Array(iv)).map((b) => b.toString(16).padStart(2, "0")).join("");
    return `${ivHex}.${encryptedDataHex}`;
  }
  async function decrypt(key, ciphertext) {
    if (!ciphertext || typeof ciphertext !== "string") {
      return null;
    }
    const [ivHex, encryptedDataHex] = ciphertext.split(".");
    if (!ivHex || !encryptedDataHex) {
      return null;
    }
    const iv = new Uint8Array(ivHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16)));
    const encryptedData = new Uint8Array(encryptedDataHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16)));
    const decryptedData = await crypto.subtle.decrypt(
      {
        name: "AES-GCM",
        iv
      },
      key,
      encryptedData
    );
    const decoder = new TextDecoder();
    return decoder.decode(decryptedData);
  }
  function getFormattedDate() {
    const date = /* @__PURE__ */ new Date();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, "0");
    const day = date.getDate().toString().padStart(2, "0");
    return `${year}-${month}-${day}`;
  }

  // edge-functions/api/1/configs/index.js
  async function onRequestGet(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const expectedToken = await sha512(token);
    let encrypt_key = await importKey(token);
    let keys_list = [];
    let list_result;
    let list_options = {
      prefix: `${expectedToken}_`,
      limit: 255
    };
    do {
      list_result = await kv_configs.list(list_options);
      if (list_result.keys === void 0) {
        break;
      }
      keys_list.push(...list_result.keys);
      list_options.cursor = list_result.cursor;
    } while (list_result.complete !== true);
    let configs = [];
    for (const item of keys_list) {
      let config_value = await kv_configs.get(item.key, "json");
      config_value.content = await decrypt(encrypt_key, config_value.content);
      configs.push(config_value);
    }
    return new Response(JSON.stringify(configs), {
      headers: {
        "content-type": "application/json"
      }
    });
  }
  async function onRequestPost(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const expectedToken = await sha512(token);
    let encrypt_key = await importKey(token);
    let req_json = await context.request.json();
    let name = req_json.name;
    if (req_json.name.length < 1) {
      name = "Unnamed config (" + getFormattedDate() + ")";
    }
    const enc_content = await encrypt(encrypt_key, "{}");
    const config = JSON.stringify({
      id: user_info.max_id + 1,
      name,
      content: enc_content,
      last_used_with_version: null,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      modified_at: (/* @__PURE__ */ new Date()).toISOString(),
      user_id: 1
    });
    await kv_configs.put(`${expectedToken}_${user_info.max_id + 1}`, config);
    await kv_users.put(expectedToken, JSON.stringify({
      username: user_info.username,
      active_config_id: user_info.max_id + 1,
      max_id: user_info.max_id + 1
    }));
    return new Response(config, {
      headers: {
        "content-type": "application/json"
      }
    });
  }

          pagesFunctionResponse = onRequestGet;
        })();
            }
          

            if(!matchedFunc && '/api/1/configs' === urlInfo.pathname && request.method === 'POST') {
              matchedFunc = true;
                "use strict";
(() => {
  // edge-functions/utils.js
  async function sha512(str) {
    const encodeContent = new TextEncoder().encode(str);
    const sha256Content = await crypto.subtle.digest(
      { name: "SHA-512" },
      encodeContent
    );
    const result = new Uint8Array(sha256Content);
    const hexString = Array.from(result).map((b) => b.toString(16).padStart(2, "0")).join("");
    return hexString;
  }
  async function checkToken(token) {
    if (!token || token.length !== 64) {
      return false;
    }
    const expectedToken = await sha512(token);
    let user_info = await kv_users.get(expectedToken, "json");
    return user_info;
  }
  async function importKey(keyHex) {
    const rawKey = new Uint8Array(
      keyHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16))
    );
    return await crypto.subtle.importKey(
      "raw",
      rawKey,
      {
        name: "AES-GCM",
        length: 256
      },
      true,
      ["encrypt", "decrypt"]
    );
  }
  async function encrypt(key, plaintext) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encoder = new TextEncoder();
    const data = encoder.encode(plaintext);
    const encryptedData = await crypto.subtle.encrypt(
      {
        name: "AES-GCM",
        iv
      },
      key,
      data
    );
    const encryptedDataHex = Array.from(new Uint8Array(encryptedData)).map((b) => b.toString(16).padStart(2, "0")).join("");
    const ivHex = Array.from(new Uint8Array(iv)).map((b) => b.toString(16).padStart(2, "0")).join("");
    return `${ivHex}.${encryptedDataHex}`;
  }
  async function decrypt(key, ciphertext) {
    if (!ciphertext || typeof ciphertext !== "string") {
      return null;
    }
    const [ivHex, encryptedDataHex] = ciphertext.split(".");
    if (!ivHex || !encryptedDataHex) {
      return null;
    }
    const iv = new Uint8Array(ivHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16)));
    const encryptedData = new Uint8Array(encryptedDataHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16)));
    const decryptedData = await crypto.subtle.decrypt(
      {
        name: "AES-GCM",
        iv
      },
      key,
      encryptedData
    );
    const decoder = new TextDecoder();
    return decoder.decode(decryptedData);
  }
  function getFormattedDate() {
    const date = /* @__PURE__ */ new Date();
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, "0");
    const day = date.getDate().toString().padStart(2, "0");
    return `${year}-${month}-${day}`;
  }

  // edge-functions/api/1/configs/index.js
  async function onRequestGet(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const expectedToken = await sha512(token);
    let encrypt_key = await importKey(token);
    let keys_list = [];
    let list_result;
    let list_options = {
      prefix: `${expectedToken}_`,
      limit: 255
    };
    do {
      list_result = await kv_configs.list(list_options);
      if (list_result.keys === void 0) {
        break;
      }
      keys_list.push(...list_result.keys);
      list_options.cursor = list_result.cursor;
    } while (list_result.complete !== true);
    let configs = [];
    for (const item of keys_list) {
      let config_value = await kv_configs.get(item.key, "json");
      config_value.content = await decrypt(encrypt_key, config_value.content);
      configs.push(config_value);
    }
    return new Response(JSON.stringify(configs), {
      headers: {
        "content-type": "application/json"
      }
    });
  }
  async function onRequestPost(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const expectedToken = await sha512(token);
    let encrypt_key = await importKey(token);
    let req_json = await context.request.json();
    let name = req_json.name;
    if (req_json.name.length < 1) {
      name = "Unnamed config (" + getFormattedDate() + ")";
    }
    const enc_content = await encrypt(encrypt_key, "{}");
    const config = JSON.stringify({
      id: user_info.max_id + 1,
      name,
      content: enc_content,
      last_used_with_version: null,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      modified_at: (/* @__PURE__ */ new Date()).toISOString(),
      user_id: 1
    });
    await kv_configs.put(`${expectedToken}_${user_info.max_id + 1}`, config);
    await kv_users.put(expectedToken, JSON.stringify({
      username: user_info.username,
      active_config_id: user_info.max_id + 1,
      max_id: user_info.max_id + 1
    }));
    return new Response(config, {
      headers: {
        "content-type": "application/json"
      }
    });
  }

          pagesFunctionResponse = onRequestPost;
        })();
            }
          

            if(!matchedFunc && '/api/1/user' === urlInfo.pathname && request.method === 'GET') {
              matchedFunc = true;
                "use strict";
(() => {
  // edge-functions/utils.js
  async function sha512(str) {
    const encodeContent = new TextEncoder().encode(str);
    const sha256Content = await crypto.subtle.digest(
      { name: "SHA-512" },
      encodeContent
    );
    const result = new Uint8Array(sha256Content);
    const hexString = Array.from(result).map((b) => b.toString(16).padStart(2, "0")).join("");
    return hexString;
  }
  async function checkToken(token) {
    if (!token || token.length !== 64) {
      return false;
    }
    const expectedToken = await sha512(token);
    let user_info = await kv_users.get(expectedToken, "json");
    return user_info;
  }
  async function generateKey() {
    let keyPair = await crypto.subtle.generateKey(
      {
        name: "AES-GCM",
        length: 256
      },
      true,
      ["encrypt", "decrypt"]
    );
    const exportedKey = await crypto.subtle.exportKey("raw", keyPair);
    const keyHex = Array.from(new Uint8Array(exportedKey)).map((b) => b.toString(16).padStart(2, "0")).join("");
    return keyHex;
  }
  async function generateToken() {
    const MAX_RETRIES = 5;
    let retries = 0;
    let token;
    do {
      token = await generateKey();
      retries++;
    } while (retries < MAX_RETRIES && await checkToken(token));
    if (retries === MAX_RETRIES) {
      token = "";
    }
    return token;
  }

  // edge-functions/api/1/user/index.js
  async function onRequestGet(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const res_json = JSON.stringify({
      id: 1,
      username: user_info.username,
      active_config_id: user_info.active_config_id,
      custom_connection_gateway: null,
      custom_connection_gateway_token: null,
      config_sync_token: token,
      is_pro: true,
      is_sponsor: false,
      github_username: user_info.username
    });
    return new Response(res_json, {
      headers: {
        "content-type": "application/json"
      }
    });
  }
  async function onRequestPost(context) {
    const isSignupDisabled = String(context.env.DISABLE_SIGNUP || "false").toLowerCase() === "true";
    if (isSignupDisabled) {
      return new Response("Signup is disabled", { status: 403 });
    }
    let req_json = await context.request.json();
    const username = req_json.username;
    if (username === void 0 || !username || username.length < 1) {
      return new Response("Invalid username", { status: 400 });
    }
    let token = await generateToken();
    if (token.length < 1) {
      return new Response("Generate Token Error", { status: 500 });
    }
    const expectedToken = await sha512(token);
    await kv_users.put(expectedToken, JSON.stringify({
      username,
      active_config_id: null,
      max_id: 0
    }));
    const res_json = JSON.stringify({
      id: 1,
      username,
      active_config_id: null,
      custom_connection_gateway: null,
      custom_connection_gateway_token: null,
      config_sync_token: token,
      is_pro: true,
      is_sponsor: false,
      github_username: username
    });
    return new Response(res_json, {
      status: 201,
      headers: {
        "content-type": "application/json"
      }
    });
  }
  async function onRequestDelete(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const expectedToken = await sha512(token);
    let keys_list = [];
    let list_options = {
      prefix: `${expectedToken}_`,
      limit: 255
    };
    let list_result;
    do {
      list_result = await kv_configs.list(list_options);
      if (list_result.keys === void 0) {
        break;
      }
      keys_list.push(...list_result.keys);
      list_options.cursor = list_result.cursor;
    } while (list_result.complete !== true);
    for (const key_name of keys_list) {
      await kv_configs.delete(key_name.key);
    }
    await kv_users.delete(expectedToken);
    return new Response(null, { status: 204 });
  }
  async function onRequestPatch(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    let new_token = await generateToken();
    if (new_token.length < 1) {
      return new Response("INTERNAL SERVER ERROR : Generate Token Error", { status: 500 });
    }
    const expectedToken = await sha512(token);
    const expectedNewToken = await sha512(new_token);
    await kv_users.put(expectedNewToken, JSON.stringify(user_info));
    await kv_users.delete(expectedToken);
    const res_json = JSON.stringify({
      id: 1,
      username: user_info.username,
      active_config_id: user_info.active_config_id,
      custom_connection_gateway: null,
      custom_connection_gateway_token: null,
      config_sync_token: new_token,
      is_pro: true,
      is_sponsor: false,
      github_username: user_info.username
    });
    return new Response(res_json, {
      status: 201,
      headers: {
        "content-type": "application/json"
      }
    });
  }

          pagesFunctionResponse = onRequestGet;
        })();
            }
          

            if(!matchedFunc && '/api/1/user' === urlInfo.pathname && request.method === 'POST') {
              matchedFunc = true;
                "use strict";
(() => {
  // edge-functions/utils.js
  async function sha512(str) {
    const encodeContent = new TextEncoder().encode(str);
    const sha256Content = await crypto.subtle.digest(
      { name: "SHA-512" },
      encodeContent
    );
    const result = new Uint8Array(sha256Content);
    const hexString = Array.from(result).map((b) => b.toString(16).padStart(2, "0")).join("");
    return hexString;
  }
  async function checkToken(token) {
    if (!token || token.length !== 64) {
      return false;
    }
    const expectedToken = await sha512(token);
    let user_info = await kv_users.get(expectedToken, "json");
    return user_info;
  }
  async function generateKey() {
    let keyPair = await crypto.subtle.generateKey(
      {
        name: "AES-GCM",
        length: 256
      },
      true,
      ["encrypt", "decrypt"]
    );
    const exportedKey = await crypto.subtle.exportKey("raw", keyPair);
    const keyHex = Array.from(new Uint8Array(exportedKey)).map((b) => b.toString(16).padStart(2, "0")).join("");
    return keyHex;
  }
  async function generateToken() {
    const MAX_RETRIES = 5;
    let retries = 0;
    let token;
    do {
      token = await generateKey();
      retries++;
    } while (retries < MAX_RETRIES && await checkToken(token));
    if (retries === MAX_RETRIES) {
      token = "";
    }
    return token;
  }

  // edge-functions/api/1/user/index.js
  async function onRequestGet(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const res_json = JSON.stringify({
      id: 1,
      username: user_info.username,
      active_config_id: user_info.active_config_id,
      custom_connection_gateway: null,
      custom_connection_gateway_token: null,
      config_sync_token: token,
      is_pro: true,
      is_sponsor: false,
      github_username: user_info.username
    });
    return new Response(res_json, {
      headers: {
        "content-type": "application/json"
      }
    });
  }
  async function onRequestPost(context) {
    const isSignupDisabled = String(context.env.DISABLE_SIGNUP || "false").toLowerCase() === "true";
    if (isSignupDisabled) {
      return new Response("Signup is disabled", { status: 403 });
    }
    let req_json = await context.request.json();
    const username = req_json.username;
    if (username === void 0 || !username || username.length < 1) {
      return new Response("Invalid username", { status: 400 });
    }
    let token = await generateToken();
    if (token.length < 1) {
      return new Response("Generate Token Error", { status: 500 });
    }
    const expectedToken = await sha512(token);
    await kv_users.put(expectedToken, JSON.stringify({
      username,
      active_config_id: null,
      max_id: 0
    }));
    const res_json = JSON.stringify({
      id: 1,
      username,
      active_config_id: null,
      custom_connection_gateway: null,
      custom_connection_gateway_token: null,
      config_sync_token: token,
      is_pro: true,
      is_sponsor: false,
      github_username: username
    });
    return new Response(res_json, {
      status: 201,
      headers: {
        "content-type": "application/json"
      }
    });
  }
  async function onRequestDelete(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const expectedToken = await sha512(token);
    let keys_list = [];
    let list_options = {
      prefix: `${expectedToken}_`,
      limit: 255
    };
    let list_result;
    do {
      list_result = await kv_configs.list(list_options);
      if (list_result.keys === void 0) {
        break;
      }
      keys_list.push(...list_result.keys);
      list_options.cursor = list_result.cursor;
    } while (list_result.complete !== true);
    for (const key_name of keys_list) {
      await kv_configs.delete(key_name.key);
    }
    await kv_users.delete(expectedToken);
    return new Response(null, { status: 204 });
  }
  async function onRequestPatch(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    let new_token = await generateToken();
    if (new_token.length < 1) {
      return new Response("INTERNAL SERVER ERROR : Generate Token Error", { status: 500 });
    }
    const expectedToken = await sha512(token);
    const expectedNewToken = await sha512(new_token);
    await kv_users.put(expectedNewToken, JSON.stringify(user_info));
    await kv_users.delete(expectedToken);
    const res_json = JSON.stringify({
      id: 1,
      username: user_info.username,
      active_config_id: user_info.active_config_id,
      custom_connection_gateway: null,
      custom_connection_gateway_token: null,
      config_sync_token: new_token,
      is_pro: true,
      is_sponsor: false,
      github_username: user_info.username
    });
    return new Response(res_json, {
      status: 201,
      headers: {
        "content-type": "application/json"
      }
    });
  }

          pagesFunctionResponse = onRequestPost;
        })();
            }
          

            if(!matchedFunc && '/api/1/user' === urlInfo.pathname && request.method === 'DELETE') {
              matchedFunc = true;
                "use strict";
(() => {
  // edge-functions/utils.js
  async function sha512(str) {
    const encodeContent = new TextEncoder().encode(str);
    const sha256Content = await crypto.subtle.digest(
      { name: "SHA-512" },
      encodeContent
    );
    const result = new Uint8Array(sha256Content);
    const hexString = Array.from(result).map((b) => b.toString(16).padStart(2, "0")).join("");
    return hexString;
  }
  async function checkToken(token) {
    if (!token || token.length !== 64) {
      return false;
    }
    const expectedToken = await sha512(token);
    let user_info = await kv_users.get(expectedToken, "json");
    return user_info;
  }
  async function generateKey() {
    let keyPair = await crypto.subtle.generateKey(
      {
        name: "AES-GCM",
        length: 256
      },
      true,
      ["encrypt", "decrypt"]
    );
    const exportedKey = await crypto.subtle.exportKey("raw", keyPair);
    const keyHex = Array.from(new Uint8Array(exportedKey)).map((b) => b.toString(16).padStart(2, "0")).join("");
    return keyHex;
  }
  async function generateToken() {
    const MAX_RETRIES = 5;
    let retries = 0;
    let token;
    do {
      token = await generateKey();
      retries++;
    } while (retries < MAX_RETRIES && await checkToken(token));
    if (retries === MAX_RETRIES) {
      token = "";
    }
    return token;
  }

  // edge-functions/api/1/user/index.js
  async function onRequestGet(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const res_json = JSON.stringify({
      id: 1,
      username: user_info.username,
      active_config_id: user_info.active_config_id,
      custom_connection_gateway: null,
      custom_connection_gateway_token: null,
      config_sync_token: token,
      is_pro: true,
      is_sponsor: false,
      github_username: user_info.username
    });
    return new Response(res_json, {
      headers: {
        "content-type": "application/json"
      }
    });
  }
  async function onRequestPost(context) {
    const isSignupDisabled = String(context.env.DISABLE_SIGNUP || "false").toLowerCase() === "true";
    if (isSignupDisabled) {
      return new Response("Signup is disabled", { status: 403 });
    }
    let req_json = await context.request.json();
    const username = req_json.username;
    if (username === void 0 || !username || username.length < 1) {
      return new Response("Invalid username", { status: 400 });
    }
    let token = await generateToken();
    if (token.length < 1) {
      return new Response("Generate Token Error", { status: 500 });
    }
    const expectedToken = await sha512(token);
    await kv_users.put(expectedToken, JSON.stringify({
      username,
      active_config_id: null,
      max_id: 0
    }));
    const res_json = JSON.stringify({
      id: 1,
      username,
      active_config_id: null,
      custom_connection_gateway: null,
      custom_connection_gateway_token: null,
      config_sync_token: token,
      is_pro: true,
      is_sponsor: false,
      github_username: username
    });
    return new Response(res_json, {
      status: 201,
      headers: {
        "content-type": "application/json"
      }
    });
  }
  async function onRequestDelete(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const expectedToken = await sha512(token);
    let keys_list = [];
    let list_options = {
      prefix: `${expectedToken}_`,
      limit: 255
    };
    let list_result;
    do {
      list_result = await kv_configs.list(list_options);
      if (list_result.keys === void 0) {
        break;
      }
      keys_list.push(...list_result.keys);
      list_options.cursor = list_result.cursor;
    } while (list_result.complete !== true);
    for (const key_name of keys_list) {
      await kv_configs.delete(key_name.key);
    }
    await kv_users.delete(expectedToken);
    return new Response(null, { status: 204 });
  }
  async function onRequestPatch(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    let new_token = await generateToken();
    if (new_token.length < 1) {
      return new Response("INTERNAL SERVER ERROR : Generate Token Error", { status: 500 });
    }
    const expectedToken = await sha512(token);
    const expectedNewToken = await sha512(new_token);
    await kv_users.put(expectedNewToken, JSON.stringify(user_info));
    await kv_users.delete(expectedToken);
    const res_json = JSON.stringify({
      id: 1,
      username: user_info.username,
      active_config_id: user_info.active_config_id,
      custom_connection_gateway: null,
      custom_connection_gateway_token: null,
      config_sync_token: new_token,
      is_pro: true,
      is_sponsor: false,
      github_username: user_info.username
    });
    return new Response(res_json, {
      status: 201,
      headers: {
        "content-type": "application/json"
      }
    });
  }

          pagesFunctionResponse = onRequestDelete;
        })();
            }
          

            if(!matchedFunc && '/api/1/user' === urlInfo.pathname && request.method === 'PATCH') {
              matchedFunc = true;
                "use strict";
(() => {
  // edge-functions/utils.js
  async function sha512(str) {
    const encodeContent = new TextEncoder().encode(str);
    const sha256Content = await crypto.subtle.digest(
      { name: "SHA-512" },
      encodeContent
    );
    const result = new Uint8Array(sha256Content);
    const hexString = Array.from(result).map((b) => b.toString(16).padStart(2, "0")).join("");
    return hexString;
  }
  async function checkToken(token) {
    if (!token || token.length !== 64) {
      return false;
    }
    const expectedToken = await sha512(token);
    let user_info = await kv_users.get(expectedToken, "json");
    return user_info;
  }
  async function generateKey() {
    let keyPair = await crypto.subtle.generateKey(
      {
        name: "AES-GCM",
        length: 256
      },
      true,
      ["encrypt", "decrypt"]
    );
    const exportedKey = await crypto.subtle.exportKey("raw", keyPair);
    const keyHex = Array.from(new Uint8Array(exportedKey)).map((b) => b.toString(16).padStart(2, "0")).join("");
    return keyHex;
  }
  async function generateToken() {
    const MAX_RETRIES = 5;
    let retries = 0;
    let token;
    do {
      token = await generateKey();
      retries++;
    } while (retries < MAX_RETRIES && await checkToken(token));
    if (retries === MAX_RETRIES) {
      token = "";
    }
    return token;
  }

  // edge-functions/api/1/user/index.js
  async function onRequestGet(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const res_json = JSON.stringify({
      id: 1,
      username: user_info.username,
      active_config_id: user_info.active_config_id,
      custom_connection_gateway: null,
      custom_connection_gateway_token: null,
      config_sync_token: token,
      is_pro: true,
      is_sponsor: false,
      github_username: user_info.username
    });
    return new Response(res_json, {
      headers: {
        "content-type": "application/json"
      }
    });
  }
  async function onRequestPost(context) {
    const isSignupDisabled = String(context.env.DISABLE_SIGNUP || "false").toLowerCase() === "true";
    if (isSignupDisabled) {
      return new Response("Signup is disabled", { status: 403 });
    }
    let req_json = await context.request.json();
    const username = req_json.username;
    if (username === void 0 || !username || username.length < 1) {
      return new Response("Invalid username", { status: 400 });
    }
    let token = await generateToken();
    if (token.length < 1) {
      return new Response("Generate Token Error", { status: 500 });
    }
    const expectedToken = await sha512(token);
    await kv_users.put(expectedToken, JSON.stringify({
      username,
      active_config_id: null,
      max_id: 0
    }));
    const res_json = JSON.stringify({
      id: 1,
      username,
      active_config_id: null,
      custom_connection_gateway: null,
      custom_connection_gateway_token: null,
      config_sync_token: token,
      is_pro: true,
      is_sponsor: false,
      github_username: username
    });
    return new Response(res_json, {
      status: 201,
      headers: {
        "content-type": "application/json"
      }
    });
  }
  async function onRequestDelete(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const expectedToken = await sha512(token);
    let keys_list = [];
    let list_options = {
      prefix: `${expectedToken}_`,
      limit: 255
    };
    let list_result;
    do {
      list_result = await kv_configs.list(list_options);
      if (list_result.keys === void 0) {
        break;
      }
      keys_list.push(...list_result.keys);
      list_options.cursor = list_result.cursor;
    } while (list_result.complete !== true);
    for (const key_name of keys_list) {
      await kv_configs.delete(key_name.key);
    }
    await kv_users.delete(expectedToken);
    return new Response(null, { status: 204 });
  }
  async function onRequestPatch(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    let new_token = await generateToken();
    if (new_token.length < 1) {
      return new Response("INTERNAL SERVER ERROR : Generate Token Error", { status: 500 });
    }
    const expectedToken = await sha512(token);
    const expectedNewToken = await sha512(new_token);
    await kv_users.put(expectedNewToken, JSON.stringify(user_info));
    await kv_users.delete(expectedToken);
    const res_json = JSON.stringify({
      id: 1,
      username: user_info.username,
      active_config_id: user_info.active_config_id,
      custom_connection_gateway: null,
      custom_connection_gateway_token: null,
      config_sync_token: new_token,
      is_pro: true,
      is_sponsor: false,
      github_username: user_info.username
    });
    return new Response(res_json, {
      status: 201,
      headers: {
        "content-type": "application/json"
      }
    });
  }

          pagesFunctionResponse = onRequestPatch;
        })();
            }
          

            if(!matchedFunc && /^\/api\/1\/configs\/([^\/]*)$/.test(urlInfo.pathname) && request.method === 'GET') {
              routeParams = {"id":["id"],"mode":1,"left":"\\/api\\/1\\/configs\\/([^\\/]*)"};
              matchedFunc = true;
                "use strict";
(() => {
  // edge-functions/utils.js
  async function sha512(str) {
    const encodeContent = new TextEncoder().encode(str);
    const sha256Content = await crypto.subtle.digest(
      { name: "SHA-512" },
      encodeContent
    );
    const result = new Uint8Array(sha256Content);
    const hexString = Array.from(result).map((b) => b.toString(16).padStart(2, "0")).join("");
    return hexString;
  }
  async function checkToken(token) {
    if (!token || token.length !== 64) {
      return false;
    }
    const expectedToken = await sha512(token);
    let user_info = await kv_users.get(expectedToken, "json");
    return user_info;
  }
  async function importKey(keyHex) {
    const rawKey = new Uint8Array(
      keyHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16))
    );
    return await crypto.subtle.importKey(
      "raw",
      rawKey,
      {
        name: "AES-GCM",
        length: 256
      },
      true,
      ["encrypt", "decrypt"]
    );
  }
  async function encrypt(key, plaintext) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encoder = new TextEncoder();
    const data = encoder.encode(plaintext);
    const encryptedData = await crypto.subtle.encrypt(
      {
        name: "AES-GCM",
        iv
      },
      key,
      data
    );
    const encryptedDataHex = Array.from(new Uint8Array(encryptedData)).map((b) => b.toString(16).padStart(2, "0")).join("");
    const ivHex = Array.from(new Uint8Array(iv)).map((b) => b.toString(16).padStart(2, "0")).join("");
    return `${ivHex}.${encryptedDataHex}`;
  }
  async function decrypt(key, ciphertext) {
    if (!ciphertext || typeof ciphertext !== "string") {
      return null;
    }
    const [ivHex, encryptedDataHex] = ciphertext.split(".");
    if (!ivHex || !encryptedDataHex) {
      return null;
    }
    const iv = new Uint8Array(ivHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16)));
    const encryptedData = new Uint8Array(encryptedDataHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16)));
    const decryptedData = await crypto.subtle.decrypt(
      {
        name: "AES-GCM",
        iv
      },
      key,
      encryptedData
    );
    const decoder = new TextDecoder();
    return decoder.decode(decryptedData);
  }

  // edge-functions/api/1/configs/[id].js
  async function onRequestGet(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const expectedToken = await sha512(token);
    let encrypt_key = await importKey(token);
    const config_id = context.params.id;
    let config_value = await kv_configs.get(`${expectedToken}_${config_id}`, "json");
    config_value.content = await decrypt(encrypt_key, config_value.content);
    return new Response(JSON.stringify(config_value), {
      headers: {
        "content-type": "application/json"
      }
    });
  }
  async function onRequestPatch(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const expectedToken = await sha512(token);
    let encrypt_key = await importKey(token);
    const config_id = context.params.id;
    let config_value = await kv_configs.get(`${expectedToken}_${config_id}`, "json");
    let req_json = await context.request.json();
    config_value.last_used_with_version = req_json.last_used_with_version;
    config_value.content = await encrypt(encrypt_key, req_json.content);
    config_value.modified_at = (/* @__PURE__ */ new Date()).toISOString();
    await kv_configs.put(`${expectedToken}_${config_id}`, JSON.stringify(config_value));
    config_value.content = await decrypt(encrypt_key, config_value.content);
    return new Response(JSON.stringify(config_value), {
      status: 200,
      headers: {
        "content-type": "application/json"
      }
    });
  }
  async function onRequestDelete(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    await kv_configs.delete(`${await sha512(token)}_${context.params.id}`);
    return new Response(null, {
      status: 204,
      headers: {
        "content-type": "application/json"
      }
    });
  }

          pagesFunctionResponse = onRequestGet;
        })();
            }
          

            if(!matchedFunc && /^\/api\/1\/configs\/([^\/]*)$/.test(urlInfo.pathname) && request.method === 'DELETE') {
              routeParams = {"id":["id"],"mode":1,"left":"\\/api\\/1\\/configs\\/([^\\/]*)"};
              matchedFunc = true;
                "use strict";
(() => {
  // edge-functions/utils.js
  async function sha512(str) {
    const encodeContent = new TextEncoder().encode(str);
    const sha256Content = await crypto.subtle.digest(
      { name: "SHA-512" },
      encodeContent
    );
    const result = new Uint8Array(sha256Content);
    const hexString = Array.from(result).map((b) => b.toString(16).padStart(2, "0")).join("");
    return hexString;
  }
  async function checkToken(token) {
    if (!token || token.length !== 64) {
      return false;
    }
    const expectedToken = await sha512(token);
    let user_info = await kv_users.get(expectedToken, "json");
    return user_info;
  }
  async function importKey(keyHex) {
    const rawKey = new Uint8Array(
      keyHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16))
    );
    return await crypto.subtle.importKey(
      "raw",
      rawKey,
      {
        name: "AES-GCM",
        length: 256
      },
      true,
      ["encrypt", "decrypt"]
    );
  }
  async function encrypt(key, plaintext) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encoder = new TextEncoder();
    const data = encoder.encode(plaintext);
    const encryptedData = await crypto.subtle.encrypt(
      {
        name: "AES-GCM",
        iv
      },
      key,
      data
    );
    const encryptedDataHex = Array.from(new Uint8Array(encryptedData)).map((b) => b.toString(16).padStart(2, "0")).join("");
    const ivHex = Array.from(new Uint8Array(iv)).map((b) => b.toString(16).padStart(2, "0")).join("");
    return `${ivHex}.${encryptedDataHex}`;
  }
  async function decrypt(key, ciphertext) {
    if (!ciphertext || typeof ciphertext !== "string") {
      return null;
    }
    const [ivHex, encryptedDataHex] = ciphertext.split(".");
    if (!ivHex || !encryptedDataHex) {
      return null;
    }
    const iv = new Uint8Array(ivHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16)));
    const encryptedData = new Uint8Array(encryptedDataHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16)));
    const decryptedData = await crypto.subtle.decrypt(
      {
        name: "AES-GCM",
        iv
      },
      key,
      encryptedData
    );
    const decoder = new TextDecoder();
    return decoder.decode(decryptedData);
  }

  // edge-functions/api/1/configs/[id].js
  async function onRequestGet(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const expectedToken = await sha512(token);
    let encrypt_key = await importKey(token);
    const config_id = context.params.id;
    let config_value = await kv_configs.get(`${expectedToken}_${config_id}`, "json");
    config_value.content = await decrypt(encrypt_key, config_value.content);
    return new Response(JSON.stringify(config_value), {
      headers: {
        "content-type": "application/json"
      }
    });
  }
  async function onRequestPatch(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const expectedToken = await sha512(token);
    let encrypt_key = await importKey(token);
    const config_id = context.params.id;
    let config_value = await kv_configs.get(`${expectedToken}_${config_id}`, "json");
    let req_json = await context.request.json();
    config_value.last_used_with_version = req_json.last_used_with_version;
    config_value.content = await encrypt(encrypt_key, req_json.content);
    config_value.modified_at = (/* @__PURE__ */ new Date()).toISOString();
    await kv_configs.put(`${expectedToken}_${config_id}`, JSON.stringify(config_value));
    config_value.content = await decrypt(encrypt_key, config_value.content);
    return new Response(JSON.stringify(config_value), {
      status: 200,
      headers: {
        "content-type": "application/json"
      }
    });
  }
  async function onRequestDelete(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    await kv_configs.delete(`${await sha512(token)}_${context.params.id}`);
    return new Response(null, {
      status: 204,
      headers: {
        "content-type": "application/json"
      }
    });
  }

          pagesFunctionResponse = onRequestDelete;
        })();
            }
          

            if(!matchedFunc && /^\/api\/1\/configs\/([^\/]*)$/.test(urlInfo.pathname) && request.method === 'PATCH') {
              routeParams = {"id":["id"],"mode":1,"left":"\\/api\\/1\\/configs\\/([^\\/]*)"};
              matchedFunc = true;
                "use strict";
(() => {
  // edge-functions/utils.js
  async function sha512(str) {
    const encodeContent = new TextEncoder().encode(str);
    const sha256Content = await crypto.subtle.digest(
      { name: "SHA-512" },
      encodeContent
    );
    const result = new Uint8Array(sha256Content);
    const hexString = Array.from(result).map((b) => b.toString(16).padStart(2, "0")).join("");
    return hexString;
  }
  async function checkToken(token) {
    if (!token || token.length !== 64) {
      return false;
    }
    const expectedToken = await sha512(token);
    let user_info = await kv_users.get(expectedToken, "json");
    return user_info;
  }
  async function importKey(keyHex) {
    const rawKey = new Uint8Array(
      keyHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16))
    );
    return await crypto.subtle.importKey(
      "raw",
      rawKey,
      {
        name: "AES-GCM",
        length: 256
      },
      true,
      ["encrypt", "decrypt"]
    );
  }
  async function encrypt(key, plaintext) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encoder = new TextEncoder();
    const data = encoder.encode(plaintext);
    const encryptedData = await crypto.subtle.encrypt(
      {
        name: "AES-GCM",
        iv
      },
      key,
      data
    );
    const encryptedDataHex = Array.from(new Uint8Array(encryptedData)).map((b) => b.toString(16).padStart(2, "0")).join("");
    const ivHex = Array.from(new Uint8Array(iv)).map((b) => b.toString(16).padStart(2, "0")).join("");
    return `${ivHex}.${encryptedDataHex}`;
  }
  async function decrypt(key, ciphertext) {
    if (!ciphertext || typeof ciphertext !== "string") {
      return null;
    }
    const [ivHex, encryptedDataHex] = ciphertext.split(".");
    if (!ivHex || !encryptedDataHex) {
      return null;
    }
    const iv = new Uint8Array(ivHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16)));
    const encryptedData = new Uint8Array(encryptedDataHex.match(/.{1,2}/g).map((byte) => parseInt(byte, 16)));
    const decryptedData = await crypto.subtle.decrypt(
      {
        name: "AES-GCM",
        iv
      },
      key,
      encryptedData
    );
    const decoder = new TextDecoder();
    return decoder.decode(decryptedData);
  }

  // edge-functions/api/1/configs/[id].js
  async function onRequestGet(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const expectedToken = await sha512(token);
    let encrypt_key = await importKey(token);
    const config_id = context.params.id;
    let config_value = await kv_configs.get(`${expectedToken}_${config_id}`, "json");
    config_value.content = await decrypt(encrypt_key, config_value.content);
    return new Response(JSON.stringify(config_value), {
      headers: {
        "content-type": "application/json"
      }
    });
  }
  async function onRequestPatch(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    const expectedToken = await sha512(token);
    let encrypt_key = await importKey(token);
    const config_id = context.params.id;
    let config_value = await kv_configs.get(`${expectedToken}_${config_id}`, "json");
    let req_json = await context.request.json();
    config_value.last_used_with_version = req_json.last_used_with_version;
    config_value.content = await encrypt(encrypt_key, req_json.content);
    config_value.modified_at = (/* @__PURE__ */ new Date()).toISOString();
    await kv_configs.put(`${expectedToken}_${config_id}`, JSON.stringify(config_value));
    config_value.content = await decrypt(encrypt_key, config_value.content);
    return new Response(JSON.stringify(config_value), {
      status: 200,
      headers: {
        "content-type": "application/json"
      }
    });
  }
  async function onRequestDelete(context) {
    const auth_header = context.request.headers.get("Authorization");
    const token = auth_header !== null ? auth_header.replace(/^Bearer\s/, "") : null;
    const user_info = await checkToken(token);
    if (!user_info) {
      return new Response("Unauthorized", { status: 403 });
    }
    await kv_configs.delete(`${await sha512(token)}_${context.params.id}`);
    return new Response(null, {
      status: 204,
      headers: {
        "content-type": "application/json"
      }
    });
  }

          pagesFunctionResponse = onRequestPatch;
        })();
            }
          

        const params = {};
        if (routeParams.id) {
          if (routeParams.mode === 1) {
            const value = urlInfo.pathname.match(routeParams.left);        
            for (let i = 1; i < value.length; i++) {
              params[routeParams.id[i - 1]] = value[i];
            }
          } else {
            const value = urlInfo.pathname.replace(routeParams.left, '');
            const splitedValue = value.split('/');
            if (splitedValue.length === 1) {
              params[routeParams.id] = splitedValue[0];
            } else {
              params[routeParams.id] = splitedValue;
            }
          }
          
        }
        if(!matchedFunc){
          pagesFunctionResponse = function() {
            return new Response(null, {
              status: 404,
              headers: {
                "content-type": "text/html; charset=UTF-8",
                "x-edgefunctions-test": "Welcome to use Pages Functions.",
              },
            });
          }
        }
        return pagesFunctionResponse({request, params, env: {"OSLogRateLimit":"64","MallocNanoZone":"0","COMMAND_MODE":"unix2003","__CFBundleIdentifier":"com.microsoft.VSCode","XPC_SERVICE_NAME":"0","DEVECOSTUDIO_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/devecostudio.vmoptions","STUDIO_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/studio.vmoptions","JETBRAINSCLIENT_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/jetbrainsclient.vmoptions","JETBRAINS_CLIENT_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/jetbrains_client.vmoptions","GATEWAY_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/gateway.vmoptions","DATASPELL_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/dataspell.vmoptions","APPCODE_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/appcode.vmoptions","RUBYMINE_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/rubymine.vmoptions","DATAGRIP_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/datagrip.vmoptions","RIDER_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/rider.vmoptions","WEBIDE_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/webide.vmoptions","WEBSTORM_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/webstorm.vmoptions","PYCHARM_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/pycharm.vmoptions","GOLAND_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/goland.vmoptions","PHPSTORM_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/phpstorm.vmoptions","CLION_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/clion.vmoptions","SSH_AUTH_SOCK":"/Users/hao/Library/Containers/com.bitwarden.desktop/Data/.bitwarden-ssh-agent.sock","IDEA_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/idea.vmoptions","PATH":"/opt/homebrew/opt/mysql-client/bin:/opt/homebrew/opt/libpq/bin:/opt/homebrew/Caskroom/miniconda/base/bin:/opt/homebrew/Caskroom/miniconda/base/condabin:/Users/hao/.bun/bin:/Users/hao/.nvm/versions/node/v25.2.1/bin:/Users/hao/bin:/Users/hao/.local/bin:/usr/local/bin:/Users/hao/Documents/Tools/Bin:/opt/homebrew/opt/llvm/bin:/Users/hao/.local/bin:/Users/hao/Library/Application Support/Code/User/globalStorage/github.copilot-chat/debugCommand:/Users/hao/Library/Application Support/Code/User/globalStorage/github.copilot-chat/copilotCli:/Users/hao/.sdkman/candidates/java/current/bin:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/System/Cryptexes/App/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/local/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/appleinternal/bin:/opt/pmk/env/global/bin:/Library/Apple/usr/bin:/Applications/Wireshark.app/Contents/MacOS:/Applications/VMware Fusion.app/Contents/Public:/usr/local/go/bin:/Users/hao/.cargo/bin:/Users/hao/Library/Application Support/Code/User/globalStorage/github.copilot-chat/debugCommand:/Users/hao/Library/Application Support/Code/User/globalStorage/github.copilot-chat/copilotCli:/Users/hao/.orbstack/bin","XPC_FLAGS":"0x0","LOGNAME":"hao","USER":"hao","HOME":"/Users/hao","SHELL":"/bin/zsh","TMPDIR":"/var/folders/vl/6h9rzzgs447273jhqvvv3t6m0000gn/T/","__CF_USER_TEXT_ENCODING":"0x1F5:0x19:0x34","ORIGINAL_XDG_CURRENT_DESKTOP":"undefined","TERM_PROGRAM":"vscode","TERM_PROGRAM_VERSION":"1.106.3","LANG":"zh_CN.UTF-8","COLORTERM":"truecolor","GIT_ASKPASS":"/Applications/Visual Studio Code.app/Contents/Resources/app/extensions/git/dist/askpass.sh","VSCODE_GIT_ASKPASS_NODE":"/Applications/Visual Studio Code.app/Contents/Frameworks/Code Helper (Plugin).app/Contents/MacOS/Code Helper (Plugin)","VSCODE_GIT_ASKPASS_EXTRA_ARGS":"","VSCODE_GIT_ASKPASS_MAIN":"/Applications/Visual Studio Code.app/Contents/Resources/app/extensions/git/dist/askpass-main.js","VSCODE_GIT_IPC_HANDLE":"/var/folders/vl/6h9rzzgs447273jhqvvv3t6m0000gn/T/vscode-git-33af430270.sock","CLAUDE_CODE_SSE_PORT":"48793","ENABLE_IDE_INTEGRATION":"true","PYTHONSTARTUP":"/Users/hao/Library/Application Support/Code/User/workspaceStorage/f3d0b8f110fb1cbb25303d0f8be46e1a/ms-python.python/pythonrc.py","PYTHON_BASIC_REPL":"1","VSCODE_INJECTION":"1","ZDOTDIR":"/Users/hao","USER_ZDOTDIR":"/Users/hao","PWD":"/Users/hao/Documents/Mark/Code/tabby-sync-edgeone","TERM":"xterm-256color","SHLVL":"1","OLDPWD":"/Users/hao/Documents/Mark/Code/tabby-sync-edgeone","VSCODE_PROFILE_INITIALIZED":"1","HOMEBREW_PREFIX":"/opt/homebrew","HOMEBREW_CELLAR":"/opt/homebrew/Cellar","HOMEBREW_REPOSITORY":"/opt/homebrew","INFOPATH":"/opt/homebrew/share/info:","SDKMAN_DIR":"/Users/hao/.sdkman","SDKMAN_CANDIDATES_API":"https://api.sdkman.io/2","SDKMAN_PLATFORM":"darwinarm64","SDKMAN_CANDIDATES_DIR":"/Users/hao/.sdkman/candidates","JAVA_HOME":"/Users/hao/.sdkman/candidates/java/current","ZSH":"/Users/hao/.oh-my-zsh","PAGER":"less","LESS":"-R","LSCOLORS":"Gxfxcxdxbxegedabagacad","LS_COLORS":"di=1;36:ln=35:so=32:pi=33:ex=31:bd=34;46:cd=34;43:su=30;41:sg=30;46:tw=30;42:ow=30;43","Q_DEFAULT_SERVER":"https://223.5.5.5/dns-query","NVM_DIR":"/Users/hao/.nvm","NVM_CD_FLAGS":"-q","NVM_BIN":"/Users/hao/.nvm/versions/node/v25.2.1/bin","NVM_INC":"/Users/hao/.nvm/versions/node/v25.2.1/include/node","BUN_INSTALL":"/Users/hao/.bun","CONDA_EXE":"/opt/homebrew/Caskroom/miniconda/base/bin/conda","CONDA_PYTHON_EXE":"/opt/homebrew/Caskroom/miniconda/base/bin/python","CONDA_SHLVL":"1","CONDA_PREFIX":"/opt/homebrew/Caskroom/miniconda/base","CONDA_DEFAULT_ENV":"base","CONDA_PROMPT_MODIFIER":"(base) ","VSCODE_PYTHON_AUTOACTIVATE_GUARD":"1","_":"/Users/hao/.nvm/versions/node/v25.2.1/bin/edgeone","DISABLE_SIGNUP":"false","NEXT_PRIVATE_STANDALONE":"true"}, waitUntil });
      }
      addEventListener('fetch', event=>{return event.respondWith(handleRequest({request:event.request,params: {}, env: {"OSLogRateLimit":"64","MallocNanoZone":"0","COMMAND_MODE":"unix2003","__CFBundleIdentifier":"com.microsoft.VSCode","XPC_SERVICE_NAME":"0","DEVECOSTUDIO_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/devecostudio.vmoptions","STUDIO_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/studio.vmoptions","JETBRAINSCLIENT_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/jetbrainsclient.vmoptions","JETBRAINS_CLIENT_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/jetbrains_client.vmoptions","GATEWAY_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/gateway.vmoptions","DATASPELL_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/dataspell.vmoptions","APPCODE_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/appcode.vmoptions","RUBYMINE_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/rubymine.vmoptions","DATAGRIP_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/datagrip.vmoptions","RIDER_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/rider.vmoptions","WEBIDE_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/webide.vmoptions","WEBSTORM_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/webstorm.vmoptions","PYCHARM_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/pycharm.vmoptions","GOLAND_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/goland.vmoptions","PHPSTORM_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/phpstorm.vmoptions","CLION_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/clion.vmoptions","SSH_AUTH_SOCK":"/Users/hao/Library/Containers/com.bitwarden.desktop/Data/.bitwarden-ssh-agent.sock","IDEA_VM_OPTIONS":"/Users/hao/Documents/Mark/Tools/Active/jetbra/vmoptions/idea.vmoptions","PATH":"/opt/homebrew/opt/mysql-client/bin:/opt/homebrew/opt/libpq/bin:/opt/homebrew/Caskroom/miniconda/base/bin:/opt/homebrew/Caskroom/miniconda/base/condabin:/Users/hao/.bun/bin:/Users/hao/.nvm/versions/node/v25.2.1/bin:/Users/hao/bin:/Users/hao/.local/bin:/usr/local/bin:/Users/hao/Documents/Tools/Bin:/opt/homebrew/opt/llvm/bin:/Users/hao/.local/bin:/Users/hao/Library/Application Support/Code/User/globalStorage/github.copilot-chat/debugCommand:/Users/hao/Library/Application Support/Code/User/globalStorage/github.copilot-chat/copilotCli:/Users/hao/.sdkman/candidates/java/current/bin:/opt/homebrew/bin:/opt/homebrew/sbin:/usr/local/bin:/System/Cryptexes/App/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/local/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/bin:/var/run/com.apple.security.cryptexd/codex.system/bootstrap/usr/appleinternal/bin:/opt/pmk/env/global/bin:/Library/Apple/usr/bin:/Applications/Wireshark.app/Contents/MacOS:/Applications/VMware Fusion.app/Contents/Public:/usr/local/go/bin:/Users/hao/.cargo/bin:/Users/hao/Library/Application Support/Code/User/globalStorage/github.copilot-chat/debugCommand:/Users/hao/Library/Application Support/Code/User/globalStorage/github.copilot-chat/copilotCli:/Users/hao/.orbstack/bin","XPC_FLAGS":"0x0","LOGNAME":"hao","USER":"hao","HOME":"/Users/hao","SHELL":"/bin/zsh","TMPDIR":"/var/folders/vl/6h9rzzgs447273jhqvvv3t6m0000gn/T/","__CF_USER_TEXT_ENCODING":"0x1F5:0x19:0x34","ORIGINAL_XDG_CURRENT_DESKTOP":"undefined","TERM_PROGRAM":"vscode","TERM_PROGRAM_VERSION":"1.106.3","LANG":"zh_CN.UTF-8","COLORTERM":"truecolor","GIT_ASKPASS":"/Applications/Visual Studio Code.app/Contents/Resources/app/extensions/git/dist/askpass.sh","VSCODE_GIT_ASKPASS_NODE":"/Applications/Visual Studio Code.app/Contents/Frameworks/Code Helper (Plugin).app/Contents/MacOS/Code Helper (Plugin)","VSCODE_GIT_ASKPASS_EXTRA_ARGS":"","VSCODE_GIT_ASKPASS_MAIN":"/Applications/Visual Studio Code.app/Contents/Resources/app/extensions/git/dist/askpass-main.js","VSCODE_GIT_IPC_HANDLE":"/var/folders/vl/6h9rzzgs447273jhqvvv3t6m0000gn/T/vscode-git-33af430270.sock","CLAUDE_CODE_SSE_PORT":"48793","ENABLE_IDE_INTEGRATION":"true","PYTHONSTARTUP":"/Users/hao/Library/Application Support/Code/User/workspaceStorage/f3d0b8f110fb1cbb25303d0f8be46e1a/ms-python.python/pythonrc.py","PYTHON_BASIC_REPL":"1","VSCODE_INJECTION":"1","ZDOTDIR":"/Users/hao","USER_ZDOTDIR":"/Users/hao","PWD":"/Users/hao/Documents/Mark/Code/tabby-sync-edgeone","TERM":"xterm-256color","SHLVL":"1","OLDPWD":"/Users/hao/Documents/Mark/Code/tabby-sync-edgeone","VSCODE_PROFILE_INITIALIZED":"1","HOMEBREW_PREFIX":"/opt/homebrew","HOMEBREW_CELLAR":"/opt/homebrew/Cellar","HOMEBREW_REPOSITORY":"/opt/homebrew","INFOPATH":"/opt/homebrew/share/info:","SDKMAN_DIR":"/Users/hao/.sdkman","SDKMAN_CANDIDATES_API":"https://api.sdkman.io/2","SDKMAN_PLATFORM":"darwinarm64","SDKMAN_CANDIDATES_DIR":"/Users/hao/.sdkman/candidates","JAVA_HOME":"/Users/hao/.sdkman/candidates/java/current","ZSH":"/Users/hao/.oh-my-zsh","PAGER":"less","LESS":"-R","LSCOLORS":"Gxfxcxdxbxegedabagacad","LS_COLORS":"di=1;36:ln=35:so=32:pi=33:ex=31:bd=34;46:cd=34;43:su=30;41:sg=30;46:tw=30;42:ow=30;43","Q_DEFAULT_SERVER":"https://223.5.5.5/dns-query","NVM_DIR":"/Users/hao/.nvm","NVM_CD_FLAGS":"-q","NVM_BIN":"/Users/hao/.nvm/versions/node/v25.2.1/bin","NVM_INC":"/Users/hao/.nvm/versions/node/v25.2.1/include/node","BUN_INSTALL":"/Users/hao/.bun","CONDA_EXE":"/opt/homebrew/Caskroom/miniconda/base/bin/conda","CONDA_PYTHON_EXE":"/opt/homebrew/Caskroom/miniconda/base/bin/python","CONDA_SHLVL":"1","CONDA_PREFIX":"/opt/homebrew/Caskroom/miniconda/base","CONDA_DEFAULT_ENV":"base","CONDA_PROMPT_MODIFIER":"(base) ","VSCODE_PYTHON_AUTOACTIVATE_GUARD":"1","_":"/Users/hao/.nvm/versions/node/v25.2.1/bin/edgeone","DISABLE_SIGNUP":"false","NEXT_PRIVATE_STANDALONE":"true"}, waitUntil: event.waitUntil }))});